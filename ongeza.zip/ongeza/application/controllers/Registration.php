<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registration extends CI_Controller {
    
    public function __construct(){
        parent::__construct();
        $this->load->model('registration_model');
        $this->load->library('status_library');
    }
    
public function index(){
    $this->pagedata['link']= 'Registration';
    $this->pagedata['title'] = 'Dashboard | '.$this->config->item('application_name');
    $this->load->helper('form');
    $this->pagedata['customers'] = $this->registration_model->get_customers();
    $this->pagedata['gender'] = $this->registration_model->get_gender();
    $this->load->vars($this->pagedata);
    $this->load->view('registration/customers');
}

public function create(){
    $this->pagedata['link']= 'Registration';
    $this->pagedata['title'] = 'Dashboard | '.$this->config->item('application_name');
    $this->load->helper('form');
    $data['first_name'] = $this->input->post('first');
    $data['last_name'] = $this->input->post('last');
    $data['town_name'] = $this->input->post('town');
    $data['gender_id'] = $this->input->post('gender');
    if($this->registration_model->create($data)){
        $this->status_library->action_status('success','successfully saved');
    }else{
        $this->status_library->action_status('failed','failed to save data');
    }
    $this->pagedata['customers'] = $this->registration_model->get_customers();
    $this->pagedata['gender'] = $this->registration_model->get_gender();
    $this->load->vars($this->pagedata);
    $this->load->view('registration/customers');
}

public function updatedetails($key=''){
    $this->pagedata['link']= 'Registration';
    $this->pagedata['title'] = 'Dashboard | '.$this->config->item('application_name');
    $this->load->helper('form');
    $this->pagedata['customers'] = $this->registration_model->get_customers();
    $this->pagedata['gender'] = $this->registration_model->get_gender();
    $this->pagedata['newdata'] = $this->registration_model->select_one_customer($key);
    $this->load->vars($this->pagedata);
    $this->load->view('registration/customer_modify');
}

    public function viewdata($key=''){
        $this->pagedata['link']= 'Registration';
        $this->pagedata['title'] = 'Dashboard | '.$this->config->item('application_name');
        $this->load->helper('form');
        $this->pagedata['customers'] = $this->registration_model->get_customers();
        $this->pagedata['gender'] = $this->registration_model->get_gender();
        $this->pagedata['newdata'] = $this->registration_model->select_one_customer($key);
        $this->load->vars($this->pagedata);
        $this->load->view('registration/view_customer');
    }

function update(){
    $data['first_name'] = $this->input->post('first');
    $data['last_name'] = $this->input->post('last');
    $data['town_name'] = $this->input->post('town');
    $data['gender_id'] = $this->input->post('gender');
    if($this->registration_model->update($data,$this->input->post('key'))){
        $result['status'] = 'true';
        $result['message'] = 'Updated successfully';
    }else{
        $result['status'] = 'false';
        $result['message'] = 'Something went wrong, try again';
    }
    print json_encode($result);
}

public function delete_customer($key=''){
    $this->db->where('id',$key);
    $this->db->delete('customer');
    if($this->db->affected_rows()>0){
        $result['status'] = 'ok';
        $result['message'] = 'Deleted successfully';
    }else{
        $result['status'] = 'no';
        $result['message'] = checkError($this->dbexeption());
    }
    print json_encode($result);
}
    
}

