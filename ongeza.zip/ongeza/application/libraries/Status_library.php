<?php
/**
 * Created by PhpStorm.
 * User: Erick_Eve_2018
 * Date: 15/11/2019
 * Time: 10:57
 */

class Status_library
{
    private $admin;
    public function __construct() {
        $this->admin =& get_instance();
    }
    public function action_status($flag=NULL,$message=NULL) {
        switch ($flag) {
            case 'success':
                $status['flag'] = TRUE; $status['status'] = 'Success';
                $status['class'] = 'alert-success';  $status['message'] = $message;
                break;
            case 'fail':
                $status['flag'] = TRUE; $status['status'] = 'Failed';
                $status['class'] = 'alert-danger';  $status['message'] = $message;
                break;
            default:
                $status['flag'] = FALSE;
                $status['class'] = 'alert-danger';$status['message'] = 'Undefined';
                break;
        }
        $this->admin->load->vars(array('status'=>$status));
    }

}