<?php
/**
 * Created by PhpStorm.
 * User: Erick_Eve_2018
 * Date: 15/11/2019
 * Time: 10:57
 */

class Registration_library
{
    private $classes;
    public function __construct() {
        $this->classes =& get_instance();
    }
    public function action_status($flag=NULL,$message=NULL) {
        switch ($flag) {
            case 'success':
                $status['flag'] = TRUE; $status['status'] = 'Success';
                $status['class'] = 'alert-success';  $status['message'] = $message;
                break;
            case 'fail':
                $status['flag'] = TRUE; $status['status'] = 'Failed';
                $status['class'] = 'alert-danger';  $status['message'] = $message;
                break;
            default:
                $status['flag'] = FALSE;
                $status['class'] = 'alert-danger';$status['message'] = 'Undefined';
                break;
        }
        $this->classes->load->vars(array('status'=>$status));
    }

    public function validate_class(){
        $this->classes->load->library('form_validation');
        $data['class_name'] = $this->classes->input->post('class');
        $data['class_desks'] = $this->classes->input->post('tch3');
        $this->classes->form_validation->set_data($data);
        $rules = array(
            array(
                'field' => 'class_name',
                'label' => 'Class name',
                'rules' => 'required'
            ),
            array(
                'field' => 'class_desks',
                'label' => 'Total number of desks',
                'rules' => 'required'
            ),
        );

        $this->classes->form_validation->set_rules($rules);
        if ($this->classes->form_validation->run() == TRUE)
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }

    }

}