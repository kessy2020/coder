<?php


class Registration_model extends CI_Model
{
public function __construct()
{
    parent::__construct();
}

    public function get_customers(){
        $query = $this->db->get('customer');
        return $query->result_array();
    }

    public function get_gender(){
        $query = $this->db->get('gender');
        return $query->result_array();
    }

    public function create($data){
        $this->db->insert('customer',$data);
        return ($this->db->affected_rows()==1) ? TRUE : FALSE;
    }

    public function update($data,$key){
        $this->db->limit(1);
        $this->db->where('id', $key);
        $this->db->update('customer', $data);
        return ($this->db->affected_rows()==1) ? TRUE : FALSE;
    }

    public function select_one_customer($key){
        $query = $this->db->select('*')->where('id',$key)->get('customer');
        return $query->row();
    }

}