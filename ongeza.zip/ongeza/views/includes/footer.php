<footer class="footer" style="background-color: #293442b8;color: white">
    Ongeza
</footer>
</div>
<script src="<?php echo base_url('resources');?>/assets/node_modules/jquery/jquery-3.2.1.min.js"></script>
<script src="<?php echo base_url('resources');?>/assets/node_modules/popper/popper.min.js"></script>
<script src="<?php echo base_url('resources');?>/assets/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?php echo base_url('resources');?>/dist/js/perfect-scrollbar.jquery.min.js"></script>
<script src="<?php echo base_url('resources');?>/dist/js/waves.js"></script>
<script src="<?php echo base_url('resources');?>/dist/js/sidebarmenu.js"></script>
<script src="<?php echo base_url('resources');?>/dist/js/custom.min.js"></script>
<script src="<?php echo base_url('resources');?>/assets/node_modules/raphael/raphael-min.js"></script>
<!--<script src="--><?php //echo base_url('resources');?><!--/assets/node_modules/morrisjs/morris.min.js"></script>-->
<script src="<?php echo base_url('resources');?>/assets/node_modules/jquery-sparkline/jquery.sparkline.min.js"></script>
<!--<script src="--><?php //echo base_url('resources');?><!--/assets/node_modules/toast-master/js/jquery.toast.js"></script>-->
<script src="<?php echo base_url('resources');?>/dist/js/dashboard1.js"></script>
<script src="<?php echo base_url('resources');?>/assets/node_modules/datatables/datatables.min.js"></script>
<!-- start - This is for export functionality only -->
<script src="<?php echo base_url('resources');?>/libs/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url('resources');?>/libs/buttons.flash.min.js"></script>
<script src="<?php echo base_url('resources');?>/libs/jszip.min.js"></script>
<script src="<?php echo base_url('resources');?>/libs/pdfmake.min.js"></script>
<script src="<?php echo base_url('resources');?>/libs/vfs_fonts.js"></script>
<script src="<?php echo base_url('resources');?>/libs/buttons.html5.min.js"></script>
<script src="<?php echo base_url('resources');?>/libs/buttons.print.min.js"></script>
<!-- end - This is for export functionality only -->
<script src="<?php echo base_url('resources');?>/assets/node_modules/moment/moment.js"></script>
<script src="<?php echo base_url('resources');?>/assets/node_modules/footable/js/footable.min.js"></script>
<script src="<?php echo base_url('resources');?>/dist/js/pages/footable-init.js"></script>

<script src="<?php echo base_url('resources');?>/assets/node_modules/sweetalert/sweetalert.min.js"></script>
<script src="<?php echo base_url('resources');?>/assets/node_modules/sweetalert/jquery.sweet-alert.custom.js"></script>
<script src="<?php echo base_url('resources');?>/dist/js/pages/validation.js"></script>

<script src="<?php echo base_url('resources');?>/assets/node_modules/switchery/dist/switchery.min.js"></script>
<script src="<?php echo base_url('resources');?>/assets/node_modules/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('resources');?>/assets/node_modules/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<script src="<?php echo base_url('resources');?>/assets/node_modules/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
<script src="<?php echo base_url('resources');?>/assets/node_modules/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.js" type="text/javascript"></script>
<script src="<?php echo base_url('resources');?>/assets/node_modules/dff/dff.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url('resources');?>/assets/node_modules/multiselect/js/jquery.multi-select.js"></script>
<script src="<?php echo base_url('resources');?>/assets/node_modules/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>
<script src="<?php echo base_url('resources');?>/assets/node_modules/clockpicker/dist/jquery-clockpicker.min.js"></script>
<!-- Color Picker Plugin JavaScript -->
<script src="<?php echo base_url('resources');?>/assets/node_modules/jquery-asColor/dist/jquery-asColor.js"></script>
<script src="<?php echo base_url('resources');?>/assets/node_modules/jquery-asGradient/dist/jquery-asGradient.js"></script>
<script src="<?php echo base_url('resources');?>/assets/node_modules/jquery-asColorPicker-master/dist/jquery-asColorPicker.min.js"></script>
<!-- Date Picker Plugin JavaScript -->
<script src="<?php echo base_url('resources');?>/assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<!-- Date range Plugin JavaScript -->
<script src="<?php echo base_url('resources');?>/assets/node_modules/timepicker/bootstrap-timepicker.min.js"></script>
<script src="<?php echo base_url('resources');?>/assets/node_modules/bootstrap-daterangepicker/daterangepicker.js"></script>

<script src="<?php echo base_url('resources');?>/dist/js/pages/widget-data.js"></script>

<script>
    // MAterial Date picker
    $('#mdate').bootstrapMaterialDatePicker({ weekStart: 0, time: false });
    $('#timepicker').bootstrapMaterialDatePicker({ format: 'HH:mm', time: true, date: false });
    $('#date-format').bootstrapMaterialDatePicker({ format: 'dddd DD MMMM YYYY - HH:mm' });

    $('#min-date').bootstrapMaterialDatePicker({ format: 'DD/MM/YYYY HH:mm', minDate: new Date() });
    // Clock pickers
    $('#single-input').clockpicker({
        placement: 'bottom',
        align: 'left',
        autoclose: true,
        'default': 'now'
    });
    $('.clockpicker').clockpicker({
        donetext: 'Done',
    }).find('input').change(function() {
        console.log(this.value);
    });
    $('#check-minutes').click(function(e) {
        // Have to stop propagation here
        e.stopPropagation();
        input.clockpicker('show').clockpicker('toggleView', 'minutes');
    });
    if (/mobile/i.test(navigator.userAgent)) {
        $('input').prop('readOnly', true);
    }
    // Colorpicker
    $(".colorpicker").asColorPicker();
    $(".complex-colorpicker").asColorPicker({
        mode: 'complex'
    });
    $(".gradient-colorpicker").asColorPicker({
        mode: 'gradient'
    });
    // Date Picker
    jQuery('.mydatepicker, #datepicker').datepicker();
    jQuery('#datepicker-autoclose').datepicker({
        autoclose: true,
        todayHighlight: true
    });
    jQuery('#date-range').datepicker({
        toggleActive: true
    });
    jQuery('#datepicker-inline').datepicker({
        todayHighlight: true
    });
    // Daterange picker
    $('.input-daterange-datepicker').daterangepicker({
        buttonClasses: ['btn', 'btn-sm'],
        applyClass: 'btn-danger',
        cancelClass: 'btn-inverse'
    });
    $('.input-daterange-timepicker').daterangepicker({
        timePicker: true,
        format: 'MM/DD/YYYY h:mm A',
        timePickerIncrement: 30,
        timePicker12Hour: true,
        timePickerSeconds: false,
        buttonClasses: ['btn', 'btn-sm'],
        applyClass: 'btn-danger',
        cancelClass: 'btn-inverse'
    });
    $('.input-limit-datepicker').daterangepicker({
        format: 'MM/DD/YYYY',
        minDate: '06/01/2015',
        maxDate: '06/30/2015',
        buttonClasses: ['btn', 'btn-sm'],
        applyClass: 'btn-danger',
        cancelClass: 'btn-inverse',
        dateLimit: {
            days: 6
        }
    });
</script>
<script>
    $(function () {
        // Switchery
        var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
        $('.js-switch').each(function () {
            new Switchery($(this)[0], $(this).data());
        });
        // For select 2
        $(".select2").select2();
        $('.selectpicker').selectpicker();
        //Bootstrap-TouchSpin
        $(".vertical-spin").TouchSpin({
            verticalbuttons: true
        });
        var vspinTrue = $(".vertical-spin").TouchSpin({
            verticalbuttons: true
        });
        if (vspinTrue) {
            $('.vertical-spin').prev('.bootstrap-touchspin-prefix').remove();
        }
        $("input[name='tch1']").TouchSpin({
            min: 0,
            max: 100,
            step: 0.1,
            decimals: 2,
            boostat: 5,
            maxboostedstep: 10,
            postfix: '%'
        });
        $("input[name='tch2']").TouchSpin({
            min: -1000000000,
            max: 1000000000,
            stepinterval: 50,
            maxboostedstep: 10000000,
            prefix: '$'
        });
        $("input[name='tch3']").TouchSpin();
        $("input[name='tch3_22']").TouchSpin({
            initval: 40
        });
        $("input[name='tch5']").TouchSpin({
            prefix: "pre",
            postfix: "post"
        });
        // For multiselect
        $('#pre-selected-options').multiSelect();
        $('#optgroup').multiSelect({
            selectableOptgroup: true
        });
        $('#public-methods').multiSelect();
        $('#select-all').click(function () {
            $('#public-methods').multiSelect('select_all');
            return false;
        });
        $('#deselect-all').click(function () {
            $('#public-methods').multiSelect('deselect_all');
            return false;
        });
        $('#refresh').on('click', function () {
            $('#public-methods').multiSelect('refresh');
            return false;
        });
        $('#add-option').on('click', function () {
            $('#public-methods').multiSelect('addOption', {
                value: 42,
                text: 'test 42',
                index: 0
            });
            return false;
        });
        $(".ajax").select2({
            ajax: {
                url: "https://api.github.com/search/repositories",
                dataType: 'json',
                delay: 250,
                data: function (params) {
                    return {
                        q: params.term, // search term
                        page: params.page
                    };
                },
                processResults: function (data, params) {
                    // parse the results into the format expected by Select2
                    // since we are using custom formatting functions we do not need to
                    // alter the remote JSON data, except to indicate that infinite
                    // scrolling can be used
                    params.page = params.page || 1;
                    return {
                        results: data.items,
                        pagination: {
                            more: (params.page * 30) < data.total_count
                        }
                    };
                },
                cache: true
            },
            escapeMarkup: function (markup) {
                return markup;
            }, // let our custom formatter work
            minimumInputLength: 1,
            //templateResult: formatRepo, // omitted for brevity, see the source of this page
            //templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
        });
    });
</script>
<script>
    $(function() {
        $('#myTable').DataTable();
        $(function() {
            var table = $('#example').DataTable({
                "columnDefs": [{
                    "visible": false,
                    "targets": 2
                }],
                "order": [
                    [2, 'asc']
                ],
                "displayLength": 25,
                "drawCallback": function(settings) {
                    var api = this.api();
                    var rows = api.rows({
                        page: 'current'
                    }).nodes();
                    var last = null;
                    api.column(2, {
                        page: 'current'
                    }).data().each(function(group, i) {
                        if (last !== group) {
                            $(rows).eq(i).before('<tr class="group"><td colspan="5">' + group + '</td></tr>');
                            last = group;
                        }
                    });
                }
            });
            // Order by the grouping
            $('#example tbody').on('click', 'tr.group', function() {
                var currentOrder = table.order()[0];
                if (currentOrder[0] === 2 && currentOrder[1] === 'asc') {
                    table.order([2, 'desc']).draw();
                } else {
                    table.order([2, 'asc']).draw();
                }
            });
        });
    });
</script>