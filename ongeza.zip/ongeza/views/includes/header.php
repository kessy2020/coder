<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url('resources');?>/assets/images/favicon.png">
    <title>Ongeza</title>
    <link href="<?php echo base_url('resources');?>/assets/node_modules/datatables/media/css/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="<?php echo base_url('resources');?>/assets/node_modules/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url('resources');?>/assets/icons/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">
    <link href="<?php echo base_url('resources');?>/assets/icons/themify-icons/themify-icons.css" rel="stylesheet">
    <link href="<?php echo base_url('resources');?>/assets/icons/font-awesome/css/fontawesome-all.css" rel="stylesheet">

    <link href="<?php echo base_url('resources');?>/assets/icons/material-design-iconic-font/css/materialdesignicons.min.css" rel="stylesheet">

    <link href="<?php echo base_url('resources');?>/assets/node_modules/sweetalert/sweetalert.css" rel="stylesheet" type="text/css">

    <link href="<?php echo base_url('resources');?>/assets/node_modules/switchery/dist/switchery.min.css" rel="stylesheet" />
    <link href="<?php echo base_url('resources');?>/assets/node_modules/bootstrap-tagsinput/dist/bootstrap-tagsinput.css" rel="stylesheet" />
    <link href="<?php echo base_url('resources');?>/assets/node_modules/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
    <link href="<?php echo base_url('resources');?>/assets/node_modules/multiselect/css/multi-select.css" rel="stylesheet" type="text/css" />

    <link href="<?php echo base_url('resources');?>/dist/css/style.min.css" rel="stylesheet">
    <link href="<?php echo base_url('resources');?>/dist/css/pages/ribbon-page.css" rel="stylesheet">
    <link href="<?php echo base_url('resources');?>/assets/node_modules/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet">

    <link href="<?php echo base_url('resources');?>/assets/node_modules/jquery-asColorPicker-master/dist/css/asColorPicker.css" rel="stylesheet">

    <link href="<?php echo base_url('resources');?>/assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />

    <link href="<?php echo base_url('resources');?>/assets/node_modules/timepicker/bootstrap-timepicker.min.css" rel="stylesheet">
    <link href="<?php echo base_url('resources');?>/assets/node_modules/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
    <link href="<?php echo base_url('resources');?>/assets/node_modules/footable/css/footable.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url('resources');?>/dist/css/pages/footable-page.css" rel="stylesheet">
    <link href="<?php echo base_url('resources');?>/dist/css/pages/other-pages.css" rel="stylesheet">
    <link href="<?php echo base_url('resources');?>/dist/css/pages/tab-page.css" rel="stylesheet">
    <link href="<?php echo base_url('resources');?>/dist/css/pages/widget-page.css" rel="stylesheet">

    <link href="<?php echo base_url('resources');?>/assets/node_modules/css-chart/css-chart.css" rel="stylesheet">
    <link href="<?php echo base_url('resources');?>/dist/css/pages/widget-page.css" rel="stylesheet">

</head>
<body class="skin-red-dark fixed-layout">

<div class="preloader">
    <div class="loader">
        <div class="loader__figure"></div>
        <p class="loader__label">Loading...</p>
    </div>
</div>

<div id="main-wrapper">