<div class="row page-titles">
    <div class="row col-md-7 align-self-center">
        <h4 class="text-themecolor" style="color: #00b286;font-size: 20px">Register customer</h4>
        <a href="<?php echo base_url('/registration/'); ?>" class="btn btn-sm btn-outline-info d-none d-lg-block m-l-15">Registration</a>
    </div>
    <div class="col-md-5 align-self-center text-right">
        <div class="d-flex justify-content-end align-items-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url('/registration/'); ?>">Home</a></li>
                <li class="breadcrumb-item active">Register customer</li>
            </ol>
        </div>
    </div>
</div>