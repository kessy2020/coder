<div class="row page-titles">
    <div class="row col-md-6 align-self-center">
        <h4 class="text-themecolor" style="color: #00b286;font-size: 20px">Modify customer</h4>
    </div>
    <div class="col-md-6 align-self-center text-right">
        <div class="d-flex justify-content-end align-items-center">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url('/dashboard/'); ?>">Home</a></li>
                <li class="breadcrumb-item active">Modify customer</li>
            </ol>
            <a href="<?php echo base_url('/registration/'); ?>" class="btn btn-sm btn-info d-none d-lg-block m-l-15"><i class="fa fa-plus-circle"></i> Register customer</a>
        </div>
    </div>
</div>