<?php defined('BASEPATH') or exit('No direct script access allowed');
?>
<?php include VIEWPATH. 'includes/header.php';?>
<?php include VIEWPATH.'/menus/top.php';?>
<?php include VIEWPATH.'/menus/left.php';?>

<div class="page-wrapper">
    <div class="container-fluid">
        <?php include VIEWPATH.'/registration/sub_top/sub_top_update.php';?>
        <?php  if(!empty($status['flag'])&& $status==TRUE ):?>
            <div style="width:100%;" class="alert alert-success <?php echo $status['class'];?>">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                <?php echo $status['message'];?>
            </div>
        <?php endif;?>
        <div class="row">
            <center>
            <div class="col-lg-7">
                <div class="card" style="box-shadow: 0px 0px 10px rgba(0,169,157,0.56); border-radius:2%;">
                    <div class="card-header" style="background-color: black;color:white">
                        Modify class
                    </div>
                    <div class="card-body">
                        <form id="update" class="needs-validation" novalidate onsubmit="update(); return false;">
                        <div class="row">
                            <input type="hidden" class="form-control" name="key" value="<?php echo $newdata->id?>" required name="first">
                            <div class="form-group col-6">
                                <label class="control-label">First name</label>
                                <input type="text" class="form-control" value="<?php echo $newdata->first_name?>" required name="first">
                            </div>
                            <div class="form-group col-6">
                                <label class="control-label">Last name</label>
                                <input type="text" class="form-control" value="<?php echo $newdata->last_name?>" required name="last">
                            </div>
                            <div class="form-group col-6">
                                <label for="recipient-name" class="control-label">Gender:</label>
                                <select type="text" class="form-control" required name="gender">
                                    <option>--Select--</option>
                                    <?php foreach($gender as $cz){?>
                                        <option <?php if($newdata->gender_id == $cz['id']){ echo 'selected';}?> value="<?php echo $cz['id'];?>"><?php echo ucfirst($cz['gender_name']);?></option>
                                    <?php }?>
                                </select>
                            </div>
                            <div class="form-group col-6">
                                <label class="control-label">Town name</label>
                                <input type="text" class="form-control" required value="<?php echo $newdata->town_name;?>" name="town">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6"> <button type="submit" class="btn btn-block btn-success">Update details</button></div>
                            <div class="col-6"> <a href="<?php echo base_url('registration')?>" class="btn btn-block btn-info">All customers</a></div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
            </center>
        </div>
    </div>
</div>
<?php include VIEWPATH. 'includes/footer.php';?>
<?php include VIEWPATH.'/registration/scripts.php';?>
</body>
</html>