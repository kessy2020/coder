<?php defined('BASEPATH') or exit('No direct script access allowed');
?>
<?php include VIEWPATH. 'includes/header.php';?>
<?php include VIEWPATH.'/menus/top.php';?>
<?php include VIEWPATH.'/menus/left.php';?>

<div class="page-wrapper">
    <div class="container-fluid">
        <?php include VIEWPATH.'/registration/sub_top/sub_top_create.php';?>
        <?php  if(!empty($status['flag'])&& $status==TRUE ):?>
            <div style="width:100%;" class="alert alert-success <?php echo $status['class'];?>">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                <?php echo $status['message'];?>
            </div>
        <?php endif;?>
        <div class="row">
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header" style="background-color: black;color:white">
                        Register customer
                    </div>
                    <div class="card-body">
                        <?php echo form_open(base_url('registration/create'));?>
                            <div class="row">
                                <div class="form-group col-6">
                                    <label class="control-label">First name</label>
                                    <input type="text" class="form-control" required name="first">
                                </div>
                                <div class="form-group col-6">
                                    <label class="control-label">Last name</label>
                                    <input type="text" class="form-control" required name="last">
                                </div>
                                <div class="form-group col-6">
                                    <label for="recipient-name" class="control-label">Gender:</label>
                                    <select type="text" class="form-control" required name="gender">
                                        <option>--Select--</option>
                                        <?php foreach($gender as $cz){?>
                                            <option value="<?php echo $cz['id'];?>"><?php echo ucfirst($cz['gender_name']);?></option>
                                        <?php  } ?>
                                    </select>
                                </div>
                                <div class="form-group col-6">
                                    <label class="control-label">Town name</label>
                                    <input type="text" class="form-control" required name="town">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6"> <button type="submit" class="btn btn-block btn-success">Save details</button></div>
                                <div class="col-6"><button type="reset" class="btn btn-block btn-danger">Clear fields</button></div>
                            </div>
                        <?php echo form_close();?>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header" style="background-color: black;color:white">
                        List of customers
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                <thead style="background-color: #93a0abb8;color: #150f6f;">
                                    <tr>
                                        <th>#</th>
                                        <th>Customer name</th>
                                        <th>Gender</th>
                                        <th>Town</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tfoot style="background-color: #93a0abb8;color: #150f6f;">
                                <tr>
                                    <th>#</th>
                                    <th>Customer name</th>
                                    <th>Gender</th>
                                    <th>Town</th>
                                    <th>Actions</th>
                                </tr>
                                </tfoot>
                                <tbody>
                                <?php if(!empty($customers)){
                                    foreach ($customers as $key=> $row ){$key++;?>
                                        <tr id="id-<?php echo $row['id'];?>">
                                            <td><?php echo $key;?></td>
                                            <td><?php echo ucfirst($row['first_name']);?> <?php echo ucfirst($row['last_name']);?></td>
                                            <td>
                                                <?php $obj =& get_instance();
                                                $query = $obj->db->select('*')->where('id',$row['gender_id'])->get('gender')->row();
                                                print $query->gender_name;
                                                ?>
                                            </td>
                                            <td><?php echo $row['town_name'];?></td>
                                            <td nowrap="">
                                                <a href="<?php echo base_url('/registration/updatedetails/').$row['id']; ?>" data-toggle="tooltip" data-original-title="edit"><i style="color: orange" class="fas fa-edit"></i></a>
                                                <a href="<?php echo base_url('/registration/viewdata/').$row['id']; ?>" data-toggle="tooltip" data-original-title="view"><i style="color: blue" class="fas fa-eye"></i></a>
                                                <a onclick="deletecustomer(<?php echo $row['id'];?>)" href="javascript:(0);" data-toggle="tooltip" data-original-title="Delete">
                                                    <i style="color: #ff5358" class="fa fa-trash"></i></a>
                                            </td>
                                        </tr>
                                    <?php }} ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include VIEWPATH. 'includes/footer.php';?>
<?php include VIEWPATH.'/registration/scripts.php';?>
</body>
</html>