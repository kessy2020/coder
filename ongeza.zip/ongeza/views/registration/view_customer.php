<?php defined('BASEPATH') or exit('No direct script access allowed');
?>
<?php include VIEWPATH. 'includes/header.php';?>
<?php include VIEWPATH.'/menus/top.php';?>
<?php include VIEWPATH.'/menus/left.php';?>

<div class="page-wrapper">
    <div class="container-fluid">
        <?php include VIEWPATH.'/registration/sub_top/sub_top_create.php';?>
        <?php  if(!empty($status['flag'])&& $status==TRUE ):?>
            <div style="width:100%;" class="alert alert-success <?php echo $status['class'];?>">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                <?php echo $status['message'];?>
            </div>
        <?php endif;?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <center>
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                <div class="col-12">
                                    <h3 style="color: green">Customer details:</h3>
                                    <h4 >First name: <?php echo ucfirst($newdata->first_name) ?></h4>
                                    <h4 >Last name: <?php echo ucfirst($newdata->last_name) ?></h4>
                                    <h4 >Gender: <?php
                                        $obj =& get_instance();
                                        $query = $obj->db->select('*')->where('id',$newdata->gender_id)->get('gender');
                                        print ucfirst($query->row()->gender_name);
                                        ?>
                                    </h4>
                                    <h4 >Town: <?php echo ucfirst($newdata->town_name) ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    </center>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include VIEWPATH. 'includes/footer.php';?>
<?php include VIEWPATH.'/registration/scripts.php';?>
</body>
</html>