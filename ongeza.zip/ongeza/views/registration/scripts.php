<script>
    $('#example23').DataTable({
    });
    function deletecustomer(num_key){
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "rgb(58, 150, 58)",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel",
            cancelButtonColor: 'red',
            closeOnConfirm: false,
            closeOnCancel: false
        }).then((result) => {
            if (result.value) {
                $.ajax({
                    url: '<?php echo base_url('/registration/delete_customer')?>/' + num_key,
                    type: 'get',
                    beforeSend: function(){

                    },
                    success: function(result){
                        let obj = JSON.parse(result);
                        if( obj.status == 'ok'){
                            $('tr#id-' + num_key).hide();
                            Swal.fire('',obj.message,'success');
                        }else{
                            Swal.fire('',obj.message,'warning');
                        }
                    },
                    error: function(xhr){
                    }
                });
            }else{
                Swal.fire("Cancelled", "Data not deleted", "error");
            }
        });
    }

    function update(){
        let container = document.getElementById('table_container');
        let form = $('form#update');
        let formdata = form.serialize();
        $.ajax({
            url:'<?php echo base_url('/registration/update');?>',
            data: formdata,
            type: 'post',
            beforeSend: function(){

            },
            success: function(result){
                let obj = JSON.parse(result);
                if(obj.status == 'true'){
                    Swal.fire('',obj.message,'success');
                }else{
                    Swal.fire('',obj.message,'warning');
                }

            },
            error: function(error){
                Swal.fire('',error.statusText,'warning');
            }
        })
    }
</script>