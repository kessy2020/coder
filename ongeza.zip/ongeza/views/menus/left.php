<aside class="left-sidebar">
    <div class="scroll-sidebar">
        <nav class="sidebar-nav">
            <li <?php if ($link == 'registration') echo 'class=active';?> >
                <a class="waves-effect waves-dark" href="<?php echo base_url('/registration');?>" aria-expanded="false">
                    <i class="fa fa-book"></i>
                    <span class="hide-menu">Registration</span>
                </a>
            </li>
        </nav>
    </div>
</aside>