<div class="row page-titles">
    <div class="col-md-6 align-self-center">
        <h4 class="text-themecolor">Dashboard</h4>
    </div>
    <div class="col-md-6 align-self-center text-right">
        <p>
            <img src="<?php echo base_url('resources');?>/assets/images/users/1.jpg" height="30" class="" alt="img">
            Alert.
        </p>
    </div>
</div>